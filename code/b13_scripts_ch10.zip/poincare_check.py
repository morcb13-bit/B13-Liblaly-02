"""第10章の確かめ。A：番地の輪でフィボナッチが符号つきで閉じる（整数・足し算・引き算だけ）。
B：u = ψ² と取り替えると、n = 2 で 1/u の項が消える（記号計算）。C：離散曲率の和 Σ(6 − d) = 6χ（整数）。"""
def walk(m):
    a, b, n = 0, 1, 0
    seq = [0]
    while True:
        c = a + b
        if c >= m: c -= m
        a, b = b, c; n += 1; seq.append(a)
        if a == 0 and b == 1: return n, seq
print("== A：番地 m の輪で、半周で符号が反転して閉じるか（F(n + 周期/2) ＝ −F(n)）")
for m in (13, 11, 7, 17, 10):
    T, s = walk(m)
    half = T // 2 if T - (T // 2) * 2 == 0 else None
    flip = half is not None and all((s[i + half] + s[i]) in (0, m) for i in range(T - half))
    print("  m = %2d  周期 %3d  半周で符号反転: %s" % (m, T, "はい（半周 %d）" % half if flip else "いいえ"))
import sympy as sp
s, t, n = sp.symbols("s t n"); psi = sp.Function("psi")(s, t)
u = psi ** 2
lhs = sp.diff(u, t).subs(sp.diff(psi, t), sp.diff(psi, s, 2) - (n - 1) * (1 - sp.diff(psi, s) ** 2) / psi)
rhs = sp.diff(u, s, 2) + (n - 2) * sp.diff(u, s) ** 2 / (2 * u) - 2 * (n - 1)
print("== B：ψ_t = ψ_ss − (n−1)(1 − ψ_s²)/ψ を u = ψ² で書き直すと u_t = u_ss + (n−2)u_s²/(2u) − 2(n−1) か：", "OK" if sp.simplify(lhs - rhs) == 0 else "NG")
print("   n = 2 で 1/u の項が消え u_t = u_ss − 2 になる：", "OK" if sp.simplify(rhs.subs(n, 2) - (sp.diff(u, s, 2) - 2)) == 0 else "NG")
print("== C：正二十面体を k 回分割した網の Σ(6 − d) と 6χ（V − E + F = χ）")
for k in range(0, 5):
    F = 20; E = 30; V = 12
    for _ in range(k): V, E, F = V + E, E + E + 3 * F, 4 * F    # 辺ごとに点を一つ足し、三角形を四つに割る
    deg5 = 12; deg6 = V - 12
    print("  分割 %d 回：V = %d, E = %d, F = %d, χ = %d, Σ(6 − d) = %d, 6χ = %d" % (k, V, E, F, V - E + F, deg5 * 1 + deg6 * 0, 6 * (V - E + F)))
