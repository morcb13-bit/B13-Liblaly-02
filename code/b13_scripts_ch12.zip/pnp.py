"""第12章の検定：P≠NP 予想を「匂いの地図」で見る。整数と足し算・比べ合いだけ。
部分和の地図：番地は（何枚目の札まで見たか, ここまでの和）。各点から「足す」「足さない」の二本の道。
地図の点の数は、届く和を一本のビット列に塗る「ずらして重ねる」で数える（第8章と同じ操作）。"""
import random
random.seed(20261023)

def layers(cards):
    """各段で届く和の集合（ビット列）を返す。"""
    R = 1; out = [R]
    for c in cards:
        R = R | (R << c); out.append(R)
    return out
def popcount(x): return bin(x).count("1")
def map_size(cards): return sum(popcount(L) for L in layers(cards))

print("== 検定1：札の桁が一つ増えるごとに、部分和の地図（匂いが広がる点の数）は何倍に広がるか（札 14 枚、各桁 20 組の平均）")
prev = None; rows = []
for d in range(1, 8):
    tot = 0
    for _ in range(20):
        cards = [random.randint(10 ** (d - 1), 10 ** d - 1) for _ in range(14)]
        tot += map_size(cards)
    avg = tot // 20
    rows.append((d, avg)); print("  桁 %d：地図の点 %d%s" % (d, avg, "" if prev is None else "  （前の桁の %d.%d 倍）" % (avg * 10 // prev // 10, avg * 10 // prev - (avg * 10 // prev // 10) * 10)))
    prev = avg
print("  地図の点の上限（14 枚のどれを足すかの組み合わせの数を段ごとに足したもの）:", sum(2 ** i for i in range(15)))
fib = [1, 2]
while len(fib) < 14: fib.append(fib[-1] + fib[-2])
def greedy_steps(cards, target):
    """大きい札から、引ける札を引いていく（第3章の「忘れても届く」）。調べた札の枚数を返す。"""
    steps = 0; rest = target
    for c in reversed(cards):
        steps += 1
        if c <= rest: rest -= c
    return steps, rest == 0
ok = True
for target in range(1, sum(fib) + 1):
    s, hit = greedy_steps(fib, target)
    ok &= hit and s == len(fib)
print("  対照：フィボナッチの札 14 枚では、1〜%d のどの目標にも、大きい順に引くだけ（一本道、%d 歩）で届く →" % (sum(fib), len(fib)), "OK" if ok else "NG")
bad = sum(1 for t in range(1, 2000) if (layers(fib)[-1] >> t) & 1 and not greedy_steps([2, 3, 5, 9, 17, 30, 55, 101, 180, 333, 600, 1100, 2000, 3700], t)[1])
print("  比べ：無作為に近い札 2, 3, 5, 9, 17, … では、大きい順に引くだけでは届かない目標がある：", bad, "個（届く目標のうち）")

print("== 検定2：札 12 枚以下で、地図の答え（スタートに匂いが届くか）が総当たりと一致するか。濃い方へ寄って取り出した組は目標に着地するか")
def smell_back(cards, target):
    """餌（目標）から逆向きに匂いを広げる。濃さ＝そこから目標へ届く道の本数（足し算だけ）。"""
    n = len(cards); D = [dict() for _ in range(n + 1)]
    D[n][target] = 1
    for i in range(n - 1, -1, -1):
        for s, v in D[i + 1].items():
            D[i][s] = D[i].get(s, 0) + v                       # 足さない道
            if s - cards[i] >= 0: D[i][s - cards[i]] = D[i].get(s - cards[i], 0) + v   # 足す道
    return D
def extract(cards, D):
    s = 0; pick = []
    for i in range(len(cards)):
        if D[i + 1].get(s + cards[i], 0) > 0: s += cards[i]; pick.append(cards[i])   # 濃さのある方へ寄る（足す道を先に見る）
        elif D[i + 1].get(s, 0) > 0: pass
        else: return None
    return pick
agree = 0; trials = 0; good_pick = 0; ng_ok = 0; counts_ok = 0
for _ in range(300):
    n = random.randint(4, 12); cards = [random.randint(1, 60) for _ in range(n)]
    target = random.randint(1, sum(cards))
    D = smell_back(cards, target)
    has = D[0].get(0, 0) > 0
    brute = 0
    for m in range(1 << n):
        t = 0
        for i in range(n):
            if (m >> i) & 1: t += cards[i]
        brute += (t == target)
    trials += 1; agree += (has == (brute > 0)); counts_ok += (D[0].get(0, 0) == brute)
    if has:
        p = extract(cards, D); good_pick += (p is not None and sum(p) == target)
    else:
        ng_ok += 1
print("  一致 %d / %d　濃さ＝解の個数 %d / %d　取り出した組が目標に着地 %d / %d　届かない目標で NG %d 件" % (agree, trials, counts_ok, trials, good_pick, trials - ng_ok, ng_ok))
print("→", "OK" if agree == trials and counts_ok == trials and good_pick == trials - ng_ok else "NG")
print("  対照：匂いを餌からではなく、目標と関係ない番地から広げると、答えが総当たりと食い違う件数")
bad = 0
for _ in range(100):
    n = 8; cards = [random.randint(1, 30) for _ in range(n)]; target = random.randint(1, sum(cards))
    D = smell_back(cards, target + 1)
    brute = any(sum(cards[i] for i in range(n) if (m >> i) & 1) == target for m in range(1 << n))
    bad += ((D[0].get(0, 0) > 0) != brute)
print("  食い違い", bad, "/ 100 →", "NG（期待どおり）" if bad > 0 else "?")

print("== 検定3：最短路の地図（P の側）は、地図を広げても点が重なり、爆発しないか")
def grid_bfs(L):
    """L × L の格子で、隅から匂いを広げる。届いた番地の数と、かかった歩数。"""
    seen = {(0, 0)}; front = [(0, 0)]; steps = 0
    while front:
        nxt = []
        for (x, y) in front:
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                q = (x + dx, y + dy)
                if 0 <= q[0] < L and 0 <= q[1] < L and q not in seen: seen.add(q); nxt.append(q)
        front = nxt; steps += 1 if nxt else 0
    return len(seen), steps
for L in (10, 20, 40, 80):
    pts, st = grid_bfs(L); print("  格子 %d × %d：地図の点 %d（＝ %d × %d）、匂いが端まで届く歩数 %d" % (L, L, pts, L, L, st))
print("  比べ：部分和の地図（各札 7 桁）の点の数を、札の枚数ごとに")
for n in (4, 8, 12, 16):
    cards = [random.randint(10 ** 6, 10 ** 7 - 1) for _ in range(n)]
    print("    札 %2d 枚：地図の点 %d（組み合わせの上限 %d）" % (n, map_size(cards), sum(2 ** i for i in range(n + 1))))
