"""VPB：格子を固定し、視点だけを替えて着地する穴を数える。虚数なし・平衡13進の足し算と裏返しだけ。"""
import itertools, json
from b13_balanced import add, neg, sub, sign, times_small, from_decimal, show

N = 13
Z, ONE = [0], [1]
def B(n): return from_decimal(str(n), N)          # 入口だけ 10 進の文字列から
def is0(a): return sign(a) == 0
def eq(a, b): return is0(sub(a, b, N))

def bmul(a, b):
    """掛け算＝ b の各桁ぶん a を足し、桁の位置だけずらして重ねる。"""
    out = [0]
    for j, d in enumerate(b):
        k = d if d >= 0 else -d
        t = times_small(a, k, N)
        if d < 0: t = neg(t)
        out = add(out, [0] * j + t, N)
    return out

def mm(A, Bm):
    out = []
    for i in range(len(A)):
        row = []
        for j in range(len(Bm[0])):
            acc = [0]
            for k in range(len(Bm)):
                acc = add(acc, bmul(A[i][k], Bm[k][j]), N)
            row.append(acc)
        out.append(row)
    return out
def tr(A): return [list(r) for r in zip(*A)]

def twice_flips(M, D):
    """一歩を二度踏むと D 倍に裏返るか。"""
    MM = mm(M, M); nD = neg(D)
    return eq(MM[0][0], nD) and eq(MM[1][1], nD) and is0(MM[0][1]) and is0(MM[1][0])

def square_root_of(x):
    """s·s = x となる s を 0 から 1 ずつ足して探す。なければ None。"""
    s = [0]
    while True:
        d = sub(bmul(s, s), x, N)
        if is0(d): return s
        if sign(d) > 0: return None
        s = add(s, ONE, N)

def rank(rows):
    """割り算なしの消去：下の行 ← 軸·行 − 係数·軸の行。"""
    M = [list(r) for r in rows if any(not is0(x) for x in r)]
    r = 0
    if not M: return 0
    for c in range(len(M[0])):
        piv = next((i for i in range(r, len(M)) if not is0(M[i][c])), None)
        if piv is None: continue
        M[r], M[piv] = M[piv], M[r]
        for i in range(r + 1, len(M)):
            if is0(M[i][c]): continue
            a, b = M[r][c], M[i][c]
            M[i] = [sub(bmul(a, M[i][k]), bmul(b, M[r][k]), N) for k in range(len(M[0]))]
        r += 1
        if r == len(M): break
    return r

PAIRS = list(itertools.combinations(range(4), 2))
def omega_unit(k):
    O = [[[0] for _ in range(4)] for _ in range(4)]
    i, j = PAIRS[k]; O[i][j] = [1]; O[j][i] = [-1]
    return O

def landed(v1, v2):
    (M1, D1), (M2, D2) = v1, v2
    if not (twice_flips(M1, D1) and twice_flips(M2, D2)):
        return "NG"
    s = square_root_of(bmul(D1, D2))
    cols = []
    for k in range(6):
        O = omega_unit(k)
        B11 = [[O[0][0], O[0][1]], [O[1][0], O[1][1]]]
        B22 = [[O[2][2], O[2][3]], [O[3][2], O[3][3]]]
        C   = [[O[0][2], O[0][3]], [O[1][2], O[1][3]]]
        col = []
        L = mm(mm(tr(M1), B11), M1); col += [sub(L[i][j], bmul(D1, B11[i][j]), N) for i in range(2) for j in range(2)]
        L = mm(mm(tr(M2), B22), M2); col += [sub(L[i][j], bmul(D2, B22[i][j]), N) for i in range(2) for j in range(2)]
        if s is None:
            col += [C[i][j] for i in range(2) for j in range(2)]
        else:
            L = mm(mm(tr(M1), C), M2); col += [sub(L[i][j], bmul(s, C[i][j]), N) for i in range(2) for j in range(2)]
        cols.append(col)
    rk = rank(tr(cols))
    out = B(6)
    for _ in range(rk): out = sub(out, ONE, N)     # 6 から階数ぶん 1 を引く
    return out

def mat(rows): return [[B(x) for x in r] for r in rows]
VIEWS = {
    "P1": (mat([[0, -1], [1, 0]]), B(1)),     # 入れ替えと裏返し（四分の一周）
    "P4": (mat([[0, -4], [1, 0]]), B(4)),
    "P3": (mat([[1, -2], [2, -1]]), B(3)),
    "P2": (mat([[0, -2], [1, 0]]), B(2)),
    "P7": (mat([[-1, -4], [2, 1]]), B(7)),
}

if __name__ == "__main__":
    import os
    vp = {(p["left"], p["right"]): p["landed"] for p in json.load(open("vp_result.json"))["pairs"]} if os.path.exists("vp_result.json") else {}
    old = {"P1": "i", "P4": "2i", "P3": "w", "P2": "sqrt2i", "P7": "(1+s7)/2"}
    out = {"pairs": []}; ok = True
    for a, b in itertools.combinations_with_replacement(list(VIEWS), 2):
        r = landed(VIEWS[a], VIEWS[b])
        sq = square_root_of(bmul(VIEWS[a][1], VIEWS[b][1])) is not None
        exp = B(4) if sq else B(2)
        m = (r != "NG") and eq(r, exp)
        same_vp = vp.get((old[a], old[b]))
        rec = {"left": a, "right": b, "landed": show(r, N) if r != "NG" else "NG", "expected": show(exp, N),
               "D1D2_square": sq, "match": m}
        if same_vp is not None:
            from b13_balanced import to_int
            rec["same_as_VP"] = (r != "NG") and to_int(r, N) == same_vp   # 観察者側の照合
        out["pairs"].append(rec); ok &= m
        print(f"{a} × {b}  着地 {rec['landed']}  期待 {rec['expected']}  {'OK' if m else 'NG'}  VPと一致 {rec.get('same_as_VP')}")
    fake = (mat([[1, 0], [0, 1]]), B(1))
    out["neg_fake_step"] = landed(fake, VIEWS["P1"])
    print("負の対照（何もしない一歩）:", out["neg_fake_step"])
    out["all_match"] = ok
    print("全一致:", ok)
    json.dump(out, open("vpb_result.json", "w"), ensure_ascii=False, indent=1)
