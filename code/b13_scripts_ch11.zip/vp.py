"""VP：格子 Z⁴ を固定し、視点（左右のドーナツの形）だけを替えて、着地する穴の数を整数で数える。"""
import itertools, json

VIEWS = {
    "i":        ([[0, -1], [1, 0]], 1),
    "2i":       ([[0, -4], [1, 0]], 4),
    "w":        ([[1, -2], [2, -1]], 3),
    "sqrt2i":   ([[0, -2], [1, 0]], 2),
    "(1+s7)/2": ([[-1, -4], [2, 1]], 7),
}

def mm(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def tr(A): return [list(r) for r in zip(*A)]

def valid(M, D):
    return mm(M, M) == [[-D, 0], [0, -D]]

def isqrt_exact(n):
    s = 0
    while s * s < n: s += 1
    return s if s * s == n else None

def rank(rows):
    M = [list(r) for r in rows if any(r)]
    if not M: return 0
    n, m = len(M), len(M[0]); r = 0; prev = 1
    for c in range(m):
        piv = next((i for i in range(r, n) if M[i][c] != 0), None)
        if piv is None: continue
        M[r], M[piv] = M[piv], M[r]
        for i in range(r + 1, n):
            for k in range(c + 1, m):
                M[i][k] = (M[r][c] * M[i][k] - M[i][c] * M[r][k]) // prev
            M[i][c] = 0
        prev = M[r][c]; r += 1
        if r == n: break
    return r

PAIRS = list(itertools.combinations(range(4), 2))   # (0,1)=a1b1 (0,2)=a1a2 (0,3)=a1b2 (1,2)=b1a2 (1,3)=b1b2 (2,3)=a2b2

def omega_from(x):            # 6 個の未知数 → 反対称 4×4
    O = [[0] * 4 for _ in range(4)]
    for (i, j), v in zip(PAIRS, x):
        O[i][j] = v; O[j][i] = -v
    return O

def landed_rank(v1, v2):
    (M1, D1), (M2, D2) = v1, v2
    if not (valid(M1, D1) and valid(M2, D2)):
        return "NG"
    s = isqrt_exact(D1 * D2)
    eqs = []
    # 未知数ごとの単位ベクトルで線形写像を組み立て、式の係数を取り出す
    def blocks(O):
        B11 = [[O[0][0], O[0][1]], [O[1][0], O[1][1]]]
        B22 = [[O[2][2], O[2][3]], [O[3][2], O[3][3]]]
        C   = [[O[0][2], O[0][3]], [O[1][2], O[1][3]]]
        return B11, B22, C
    cols = []
    for k in range(6):
        e = [0] * 6; e[k] = 1
        B11, B22, C = blocks(omega_from(e))
        r = []
        L = mm(mm(tr(M1), B11), M1); r += [L[i][j] - D1 * B11[i][j] for i in range(2) for j in range(2)]
        L = mm(mm(tr(M2), B22), M2); r += [L[i][j] - D2 * B22[i][j] for i in range(2) for j in range(2)]
        if s is None:
            r += [C[i][j] for i in range(2) for j in range(2)]
        else:
            L = mm(mm(tr(M1), C), M2); r += [L[i][j] - s * C[i][j] for i in range(2) for j in range(2)]
        cols.append(r)
    A = tr(cols)               # 式 × 未知数
    return 6 - rank(A)

FIELD = {"i": "Q(i)", "2i": "Q(i)", "w": "Q(√-3)", "sqrt2i": "Q(√-2)", "(1+s7)/2": "Q(√-7)"}

if __name__ == "__main__":
    out = {"pairs": []}
    ok = True
    names = list(VIEWS)
    for a, b in itertools.combinations_with_replacement(names, 2):
        r = landed_rank(VIEWS[a], VIEWS[b])
        exp = 4 if FIELD[a] == FIELD[b] else 2
        out["pairs"].append({"left": a, "right": b, "landed": r, "expected": exp, "match": r == exp})
        ok &= (r == exp)
        print(f"{a:>9} × {b:<9} 着地 {r}  期待 {exp}  {'OK' if r == exp else 'NG'}")
    neg = landed_rank(([[1, 0], [0, 1]], 1), VIEWS["i"])
    out["neg_fake_view"] = neg
    print("負の対照1（偽の視点）:", neg)
    out["all_match"] = ok
    out["values_seen"] = sorted({p["landed"] for p in out["pairs"]})
    print("全一致:", ok, " 出た値:", out["values_seen"])
    json.dump(out, open("vp_result.json", "w"), ensure_ascii=False, indent=1)
