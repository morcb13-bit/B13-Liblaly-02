import json, itertools
from ht4 import *
def ring_faces(verts, L, cplx):
    F = {}
    for i in range(L):
        tet = verts[i:i+4]
        for tri in itertools.combinations(tet, 3):
            F[frozenset(tri)] = tri
    nc = sum(1 for (p, q, w) in F.values() if cplx(sub(q, p), sub(w, p)))
    return len(F), nc
out = {}
e1, e2, e3 = (1,0,0,0), (0,1,0,0), (0,0,1,0)
out["neg_B_a1a2"] = complexB(e1, e3)
out["neg_C_a1a2"] = complexC(e1, e3)
out["pos_C_a1b1"] = complexC(e1, e2)
stages = (("B Z[i]^2", TB, complexB, [2]), ("C Z[w]^2", TC, complexC, [2, 4, 6]), ("A Z[zeta]", TA, complexA, [4, 6, 10, 14, 16]))
for name, T, cplx, ds in stages:
    n, rk = S3(T, cplx)
    st = {"S3_planes": n, "S3_rank": rk, "S1": []}
    for d in ds:
        r = S1(T, d, maxlen=40, box=3)
        if not r["tetra"]:
            st["S1"].append({"d": d, "tetra": False}); continue
        for ring in r["rings"]:
            nf, nc = ring_faces(ring["verts"], ring["L"], cplx)
            st["S1"].append({"d": d, "L": ring["L"], "lam": ring["lam"], "faces": nf, "complex_faces": nc})
    out[name] = st
print(json.dumps(out, ensure_ascii=False, indent=1))
json.dump(out, open("ht4_result.json", "w"), ensure_ascii=False, indent=1)
