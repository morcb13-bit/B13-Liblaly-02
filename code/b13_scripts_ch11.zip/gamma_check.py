"""影 Γ_λ が覆う 6 つの穴の整数と、四つの部分図形への組み分けを確かめる（整数だけ）。
λ = m + n·P1（P1 は入れ替えと裏返し）。輪の順は a1, b1, a2, b2。
"""
import itertools

def wedge(A, B):
    return {(i, j): A[i] * B[j] - A[j] * B[i] for i, j in itertools.combinations(range(4), 2)}

NAMES = {(0, 1): "a1b1", (0, 2): "a1a2", (0, 3): "a1b2", (1, 2): "b1a2", (1, 3): "b1b2", (2, 3): "a2b2"}

def gamma(m, n):
    # a1 を一周すると右は (m, n)、b1 を一周すると右は P1 をかけた (−n, m)
    return wedge([1, 0, m, n], [0, 1, -n, m])

E_PT = {k: 0 for k in NAMES}; E_PT[(0, 1)] = 1     # 左のドーナツ × 点
PT_E = {k: 0 for k in NAMES}; PT_E[(2, 3)] = 1     # 点 × 右のドーナツ
G1, GP = gamma(1, 0), gamma(0, 1)

ok = 0
for m in range(-3, 4):
    for n in range(-3, 4):
        g = gamma(m, n)
        c3 = 1 - m - n
        c4 = m * m + n * n - m - n
        comb = {k: m * G1[k] + n * GP[k] + c3 * E_PT[k] + c4 * PT_E[k] for k in NAMES}
        ok += (comb == g)
print("一致", ok, "/ 49")
print("λ = 2+P1 の 6 つの整数:", {NAMES[k]: v for k, v in gamma(2, 1).items()})
