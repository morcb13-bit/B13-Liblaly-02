"""HT4：正四面体の円環で 4 次元のドーナツの穴をなぞる。整数と足し算・整数の掛け算だけ。
使い方: python3 ht4.py
"""
import itertools, json, sys

R = range(-2, 3)

# ---------- 舞台 A：Z[ζ]（ζ⁴ = ζ³ − ζ² + ζ − 1） ----------
def zmul(a, b):
    c = [0] * 7
    for i in range(4):
        for j in range(4):
            c[i + j] += a[i] * b[j]
    for k in (6, 5, 4):              # ζ^k = ζ^{k-1} − ζ^{k-2} + ζ^{k-3} − ζ^{k-4}
        t = c[k]; c[k] = 0
        c[k-1] += t; c[k-2] -= t; c[k-3] += t; c[k-4] -= t
    return tuple(c[:4])

def zpow(k):
    x = (1, 0, 0, 0)
    for _ in range(k):
        x = zmul(x, (0, 1, 0, 0))
    return x

def zmap(img):                       # ζ^k ↦ img^k の環の写像
    pw = [(1, 0, 0, 0)]
    for _ in range(3):
        pw.append(zmul(pw[-1], img))
    def f(x):
        out = [0, 0, 0, 0]
        for k in range(4):
            for t in range(4):
                out[t] += x[k] * pw[k][t]
        return tuple(out)
    return f

tau = zmap(zpow(3))                  # ζ → ζ³
conj = zmap(zpow(9))                 # ζ → ζ⁻¹

def trace(x):                        # 掛け算の行列の対角の和
    s = 0
    for k in range(4):
        e = [0, 0, 0, 0]; e[k] = 1
        s += zmul(x, tuple(e))[k]
    return s

def TA(x):
    return trace(zmul(x, conj(x)))

def sub(a, b): return tuple(p - q for p, q in zip(a, b))
def add(a, b): return tuple(p + q for p, q in zip(a, b))

def complexA(u, v):
    return sub(zmul(u, tau(v)), zmul(tau(u), v)) == (0, 0, 0, 0)

# ---------- 舞台 B：Z⁴ = Z[i]² ----------
def TB(x): return sum(t * t for t in x)
def J(x): return (-x[1], x[0], -x[3], x[2])

def minors3(a, b, c):
    M = [a, b, c]
    out = []
    for cols in itertools.combinations(range(4), 3):
        m = [[M[r][k] for k in cols] for r in range(3)]
        d = (m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
             - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
             + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]))
        out.append(d)
    return out

def complexB(u, v):
    return all(d == 0 for d in minors3(u, J(u), v))

# ---------- 共通 ----------
def wedge(u, v):
    return tuple(u[i] * v[j] - u[j] * v[i] for i, j in itertools.combinations(range(4), 2))

def rank(rows):                      # 分数を使わない消去（Bareiss）
    M = [list(r) for r in rows if any(r)]
    if not M: return 0
    n, m = len(M), len(M[0]); r = 0; prev = 1
    for c in range(m):
        piv = next((i for i in range(r, n) if M[i][c] != 0), None)
        if piv is None: continue
        M[r], M[piv] = M[piv], M[r]
        for i in range(r + 1, n):
            for k in range(c + 1, m):
                M[i][k] = (M[r][c] * M[i][k] - M[i][c] * M[r][k]) // prev
            M[i][c] = 0
        prev = M[r][c]; r += 1
        if r == n: break
    return r

def independent(u, v):
    return any(wedge(u, v))

def S3(T, cplx):
    vecs = [v for v in itertools.product(R, repeat=4) if any(v)]
    classes, n = [], 0
    for u, v in itertools.combinations(vecs, 2):
        if independent(u, v) and cplx(u, v):
            n += 1
            classes.append(wedge(u, v))
    # 階数は代表を間引いてから
    uniq = list({c for c in classes})
    return n, rank(uniq)

def S1(T, d, maxlen=60, box=3):
    """一辺の長さ² d の正四面体の鎖。状態 = 直前 3 頂点の差。周期と平行移動を探す。"""
    S = [v for v in itertools.product(range(-box, box + 1), repeat=4) if any(v) and T(v) == d]
    Sset = set(S)
    def ok(p, q): return T(sub(p, q)) == d
    o = (0, 0, 0, 0)
    found = []
    for a in S:
        for b in S:
            if not ok(a, b): continue
            for c in S:
                if ok(a, c) and ok(b, c):
                    found.append((o, a, b, c))
                    break
            if found: break
        if found: break
    if not found:
        return {"d": d, "tetra": False}
    start = list(found[0])
    # 深さ優先で鎖を伸ばし、状態（v1−v0, v2−v0, v3−v0）の繰り返しを探す
    def state(ch): return (sub(ch[-3], ch[-4]), sub(ch[-2], ch[-4]), sub(ch[-1], ch[-4]))
    best = []
    def nexts(ch):
        p, q, r = ch[-3], ch[-2], ch[-1]
        out = []
        for s in S:
            w = add(r, s)
            if w != ch[-4] and ok(w, p) and ok(w, q) and w not in (p, q, r):
                out.append(w)
        return out
    rings = []
    sys.setrecursionlimit(10000)
    seen_states = {}
    def dfs(ch, depth):
        if rings and len(rings) >= 4: return
        st = state(ch)
        if st in seen_states and seen_states[st] < len(ch) - 1:
            k = seen_states[st]
            L = len(ch) - 1 - k
            lam = sub(ch[-4], ch[k - 3])
            rings.append({"L": L, "lam": lam, "verts": ch[k-3:]})
            return
        if depth >= maxlen: return
        seen_states[st] = len(ch) - 1
        for w in nexts(ch):
            dfs(ch + [w], depth + 1)
        del seen_states[st]
    dfs(start, 0)
    return {"d": d, "tetra": True, "start": start, "rings": rings}

if __name__ == "__main__":
    out = {}
    # 長さ²の表
    out["A_norms_small"] = sorted({TA(v) for v in itertools.product(R, repeat=4) if any(v)})[:8]
    # 負の対照
    e1, e3 = (1, 0, 0, 0), (0, 0, 1, 0)
    out["B_neg_a1a2_complex"] = complexB(e1, e3)
    out["B_pos_a1b1_complex"] = complexB(e1, (0, 1, 0, 0))
    for name, T, cplx in (("B", TB, complexB), ("A", TA, complexA)):
        n, rk = S3(T, cplx)
        out[name + "_S3_planes"] = n
        out[name + "_S3_rank"] = rk
    print(json.dumps(out, ensure_ascii=False, indent=1))

# ---------- 正の対照 C：Z[ω]²（六角形のドーナツ二つ、ω² = −1 − ω） ----------
def TC(x):
    a, b, c, e = x
    return 2 * (a * a - a * b + b * b) + 2 * (c * c - c * e + e * e)
def W(x):                            # ω 倍（両方のドーナツで同じ）
    a, b, c, e = x
    return (-b, a - b, -e, c - e)
def complexC(u, v):
    return all(d == 0 for d in minors3(u, W(u), v))
